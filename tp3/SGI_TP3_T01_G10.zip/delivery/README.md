# SGI 2023/2024 - TP3


## Group T01G10
| Name                         | Number    | E-Mail             |
| ---------------------------- | --------- | ------------------ |
| Eduardo Duarte da Silva      | 202004999 | 202004999@up.pt    |
| Adam Gershenson Nogueira     | 202007519 | 202007519@up.pt    |


# Scene description

This scene representes a race between two cars set in a desert where some locals like to sit by and watch the race, the fastest and most skilled wins after 3 laps! To control the car, you can use the WASD keys or the arrow keys.

# Rendered Images

![screenShot1](screenshots/sc1.png)
![screenShot2](screenshots/sc2.png)


